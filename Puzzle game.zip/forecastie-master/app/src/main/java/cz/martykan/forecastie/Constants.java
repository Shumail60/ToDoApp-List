package cz.martykan.forecastie;

public class Constants {
    public static final String  DEFAULT_CITY = "London";
    public static final String  DEFAULT_LAT = "51.5072";
    public static final String  DEFAULT_LON = "0.1275";
}
